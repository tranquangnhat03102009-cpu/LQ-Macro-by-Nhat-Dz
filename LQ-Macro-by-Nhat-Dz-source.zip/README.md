# LQ Macro by Nhật Dz

Android starter project (Kotlin + Jetpack Compose).

## Current features
- Dark / purple neon interface
- Create, edit, delete macro profiles
- Search by name, category, or notes
- Local storage on the device using SharedPreferences

This starter app stores macro profiles and notes only. It does not automate gameplay,
inject input into Liên Quân, or modify the game.

## Build
The included GitHub Actions workflow builds a debug APK on pushes to `main`
or by manually running the workflow from the Actions tab.
