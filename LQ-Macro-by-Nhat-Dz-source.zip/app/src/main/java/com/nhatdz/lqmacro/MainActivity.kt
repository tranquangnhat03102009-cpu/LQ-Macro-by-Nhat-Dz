package com.nhatdz.lqmacro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF0B0812)
private val Panel = Color(0xFF191225)
private val Purple = Color(0xFFB66CFF)
private val Muted = Color(0xFFB9AFC8)

data class MacroItem(
    val id: Long,
    val name: String,
    val description: String,
    val category: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("lq_macro_local", MODE_PRIVATE)
        setContent {
            var macros by remember {
                mutableStateOf(loadMacros(prefs.getString("items", "[]") ?: "[]"))
            }
            var query by remember { mutableStateOf("") }
            var showEditor by remember { mutableStateOf(false) }
            var editing by remember { mutableStateOf<MacroItem?>(null) }

            fun persist(updated: List<MacroItem>) {
                macros = updated
                prefs.edit().putString("items", saveMacros(updated)).apply()
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    background = Bg,
                    surface = Panel,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Column(Modifier.fillMaxSize().padding(18.dp)) {
                        Text("LQ MACRO", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("BY NHẬT DZ  •  MACRO LIBRARY", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(22.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Thư viện của bạn", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Text("${macros.size} cấu hình đã lưu trên thiết bị", color = Muted, fontSize = 12.sp)
                            }
                            FilledTonalIconButton(onClick = {
                                editing = null
                                showEditor = true
                            }) {
                                Icon(Icons.Default.Add, contentDescription = "Tạo macro")
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Tìm macro...", color = Muted) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Purple,
                                unfocusedBorderColor = Color(0xFF443653),
                                cursorColor = Purple
                            )
                        )
                        Spacer(Modifier.height(14.dp))

                        if (macros.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Chưa có macro nào", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Nhấn nút + để tạo cấu hình đầu tiên", color = Muted, fontSize = 12.sp)
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(macros.filter {
                                    it.name.contains(query, true) ||
                                    it.category.contains(query, true) ||
                                    it.description.contains(query, true)
                                }, key = { it.id }) { item ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Panel),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(Modifier.padding(14.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Column(Modifier.weight(1f)) {
                                                    Text(item.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                                    Text(item.category, color = Purple, fontSize = 11.sp)
                                                }
                                                IconButton(onClick = {
                                                    editing = item
                                                    showEditor = true
                                                }) {
                                                    Icon(Icons.Default.Edit, contentDescription = "Sửa", tint = Purple)
                                                }
                                                IconButton(onClick = {
                                                    persist(macros.filterNot { it.id == item.id })
                                                }) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Xóa", tint = Color(0xFFFF6B8A))
                                                }
                                            }
                                            if (item.description.isNotBlank()) {
                                                Text(item.description, color = Muted, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (showEditor) {
                    MacroEditor(
                        initial = editing,
                        onDismiss = { showEditor = false },
                        onSave = { item ->
                            val next = if (editing == null) macros + item
                            else macros.map { if (it.id == item.id) item else it }
                            persist(next)
                            showEditor = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun MacroEditor(
    initial: MacroItem?,
    onDismiss: () -> Unit,
    onSave: (MacroItem) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "Khác") }
    var description by remember { mutableStateOf(initial?.description ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(if (initial == null) "Tạo macro mới" else "Chỉnh sửa macro") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Tên macro") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Danh mục") }, singleLine = true)
                OutlinedTextField(
                    description, { description = it },
                    label = { Text("Mô tả / ghi chú cấu hình") },
                    minLines = 3
                )
                Text("Đây là hồ sơ cấu hình được lưu cục bộ; không tự động điều khiển trò chơi.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(MacroItem(initial?.id ?: System.currentTimeMillis(), name.trim(),
                        description.trim(), category.trim().ifBlank { "Khác" }))
                }
            ) { Text("Lưu", color = Purple) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

private fun saveMacros(items: List<MacroItem>): String {
    val array = JSONArray()
    items.forEach {
        array.put(JSONObject().put("id", it.id).put("name", it.name)
            .put("description", it.description).put("category", it.category))
    }
    return array.toString()
}

private fun loadMacros(raw: String): List<MacroItem> {
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            MacroItem(o.optLong("id"), o.optString("name"),
                o.optString("description"), o.optString("category", "Khác"))
        }
    } catch (_: Exception) {
        emptyList()
    }
}
